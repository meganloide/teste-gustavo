classes += props.operator ? 'operator' : '';
    return (
        <button
            data-cy='btn'
            onClick={e => props.click && props.click(props.label)}
            className={classes}>
        {props.label}
        </button>
    )

    
